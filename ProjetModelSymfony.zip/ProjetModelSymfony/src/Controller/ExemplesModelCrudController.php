<?php

namespace App\Controller;

use App\Entity\Aeroport;
use App\Entity\Eleve;
use App\Entity\Inscription;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class ExemplesModelCrudController extends AbstractController
{
    #[Route('/insert/aeroport', name: 'insert_aeroport')]
    public function insertAeroport(ManagerRegistry $doctrine): Response
    {
        $a1= new Aeroport();
        $a1->setNom("Brussels Aeroport");
        $a1->setCode("ZAV");
        

        $em =$doctrine->getManager();
        $em->persist($a1);
        $em->flush();

        return $this->render('exemples_model_crud/insert_aeroport.html.twig');
    }

    #[Route('/insert/eleve', name: 'insert_eleve')]
    public function insertEleve(ManagerRegistry $doctrine) {
        $e1= new Eleve([
            'nom' => 'Bojabah',
            'Anissa'=>'Anissa',
        ]);
        

        $e2= new Eleve();
        $e2->setNom("Kempinaire");
        $e2->setPrenom("Camille");

    
        $em=$doctrine->getManager();
        $em->persist($e1);
        $em->persist($e2);
        $em->flush();

        return $this->render('exemples_model_crud/insert_eleve.html.twig');
    }

    #[Route('/insert/eleve/inscription', name: 'insert_eleve')]
    public function insertEleveInscription(ManagerRegistry $doctrine) {
        $e1=new Eleve([
            'nom'=>'Pehlivan',
            'prenom'=>'sara'
        ]);

    $i1=new Inscription([
        'commentaire'=>"tout va mal",
    ]);

    $i2=new Inscription([
    
        'commentaire'=>"tout va mal",
    ]);
    $e1->addInscription($i1);
    $e1->addInscription($i2);

$em=$doctrine->getManager();
$em->persist($e1);



$em->flush();
return $this->render('exemples_model_crud/insert_eleve_inscription.html.twig');
}

#[Route('/insert/eleve/inscription', name: 'insert_eleve')]
    public function obtenirEleve(ManagerRegistry $doctrine) {
        $em= $doctrine ->getManager();
        $rep=$em->getRepository(Eleve::class);
        $arrEleves=$rep->findAll();
        $vars=[
            'array' => $arrEleves,
        ];
        return $this->render('exemples_model_crud/obtenirEleve.html.twig');
    }
}